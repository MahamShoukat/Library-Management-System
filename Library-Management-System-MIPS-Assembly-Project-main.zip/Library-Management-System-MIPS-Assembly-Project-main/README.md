# Library-Management-System-MIPS-Assembly-Project
The LMS is divided into two main components: the admin module and the user module. Admins
are provided with tools to manage the library's inventory, including adding, viewing, updating, and
removing books. Users, on the other hand, can view available books, borrow and return them, and
search the books through their Id. The system is built with a simple text-based interface, ensuring
ease of use while focusing on core functionalities.
